### Exercise 3 -- Task 2

Use the Makefile to compile the program.
Run with `make run`
